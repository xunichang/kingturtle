# 王八钟 / King Turtle Clock v3.0

一个 Curios 饰品：佩戴在**护符栏**或**通用饰品栏**后，按百分比降低移动速度。

## 实现方式（v3.0 重点）

减速**不使用 Mixin**，而是给玩家的 `MOVEMENT_SPEED` 属性动态挂一个
`Operation.MULTIPLY_TOTAL` 修饰符。

Minecraft 的速度结算分三层：

```
最终速度 =（基础值 + 加法乘区）×（1 + 乘法乘区）× 独立乘法乘区
```

- 加法乘区：`ADDITION`
- 乘法乘区：`MULTIPLY_BASE`
- **独立乘法乘区：`MULTIPLY_TOTAL`** —— 每个修饰符以 `(1 + amount)` 的因子连乘

本模组把减速放进第三层「独立乘法乘区」：

- 减速到原速的 `k`（如 50% → `k = 0.5`）时，修饰符 `amount = k - 1`（如 `-0.5`）；
- 最终速度乘以 `(1 + (k - 1)) = k`，即在所有其它移速计算**之后**再单独乘一次；
- 原版疾跑加成（`SPEED_MODIFIER_SPRINTING`，`MULTIPLY_TOTAL +0.3`）也在这一层，
  所以减速**同时覆盖行走与疾跑**。

## 佩戴逻辑

- 每个服务端 tick 检测一次是否佩戴，动态增删修饰符。
- 使用固定 UUID + 临时修饰符（`addTransientModifier`，不写入存档），
  不会重复叠加、取下立即恢复、重登不残留。
- 同时佩戴多个时，取**最慢**（档位数值最小）的那个生效。

## 档位与操作

- 档位：**95% 到 5%，每 5% 一档，共 19 档**（原速的百分比）。
- **手持右键**循环切换档位。
- 佩戴槽位限定 `curios:charm` 与 `curios:curio`（通过 Curios 标签实现）。

## 配方

原版时钟 ×1 + 原石 ×8（围绕时钟一圈）。

```
CCC
CWC
CCC
C = minecraft:cobblestone , W = minecraft:clock
```

## 构建

需要 JDK 17+。

```bash
# 1) 生成 wrapper（只需一次）
gradle wrapper

# 2) 构建
# Windows CMD:
gradlew.bat build
# Linux / macOS / PowerShell:
./gradlew build
```

产物：`build/libs/kingturtle-3.0.0.jar`

## 配置

首次运行后生成 `config/kingturtle-common.toml`：

```toml
[general]
    # 可选减速档位（百分比），默认 95 到 5 每 5 一档
    tiers = [95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15, 10, 5]
    # 新合成饰品的初始减速档位（百分比）
    defaultTier = 95
```
