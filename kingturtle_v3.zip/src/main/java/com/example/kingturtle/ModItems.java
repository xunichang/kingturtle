package com.example.kingturtle;

import com.example.kingturtle.item.KingTurtleClockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, KingTurtleMod.MODID);

    public static final RegistryObject<Item> KING_TURTLE_CLOCK =
            ITEMS.register("king_turtle_clock",
                    () -> new KingTurtleClockItem(new Item.Properties().stacksTo(1)));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
