package com.example.kingturtle.item;

import com.example.kingturtle.Config;
import com.example.kingturtle.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.SlotResult;
import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;

import java.util.List;

/**
 * 王八钟 v3.0 - 属性修饰符方案
 *
 * <p>核心思路：</p>
 * <ul>
 *   <li>不再使用 Mixin 拦截 {@code getSpeed()}，改为给玩家的 {@code MOVEMENT_SPEED}
 *       属性动态挂一个 {@code Operation.MULTIPLY_TOTAL} 修饰符。</li>
 *   <li>{@code MULTIPLY_TOTAL} 修饰符在 Minecraft 里是"独立乘法乘区"：
 *       每个修饰符以 {@code (1 + amount)} 的因子被连乘到最终值上，
 *       位于加法乘区与乘法乘区之后的最后一层。</li>
 *   <li>原版疾跑加成本身也是 {@code MULTIPLY_TOTAL}（+0.3），与本减速处于同一乘区，
 *       因此减速会同时作用于行走与疾跑。</li>
 *   <li>减速系数 k（例如 0.5 = 原速的 50%）对应的修饰符 amount = k - 1（如 -0.5），
 *       最终速度乘以 (1 + (k-1)) = k。</li>
 *   <li>饰品取下后，下一个 tick 立即移除修饰符，速度瞬间恢复，无任何残留。</li>
 * </ul>
 *
 * <p>档位：95%..5%，每 5% 一档，共 19 档，手持右键循环切换。</p>
 */
public class KingTurtleClockItem extends Item {

    private static final String TAG_TIER = "SlowTier";

    public KingTurtleClockItem(Properties properties) {
        super(properties);
    }

    // ==================== 档位管理 ====================

    /** 返回排序去重后的档位数组（升序）。 */
    public static int[] getTiers() {
        int[] tiers = Config.COMMON.tiers.get().stream()
                .mapToInt(Integer::intValue)
                .sorted()
                .distinct()
                .toArray();
        return tiers.length > 0 ? tiers : new int[]{95};
    }

    /** 找到最接近的有效档位。 */
    public static int nearestTier(int value) {
        int[] tiers = getTiers();
        int best = tiers[0];
        int bestDiff = Math.abs(tiers[0] - value);
        for (int t : tiers) {
            int diff = Math.abs(t - value);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = t;
            }
        }
        return best;
    }

    /** 读取 NBT 中的档位。 */
    public static int getTier(ItemStack stack) {
        if (stack.hasTag() && stack.getTag() != null && stack.getTag().contains(TAG_TIER)) {
            return nearestTier(stack.getTag().getInt(TAG_TIER));
        }
        return nearestTier(Config.COMMON.defaultTier.get());
    }

    /** 写入档位到 NBT。 */
    public static void setTier(ItemStack stack, int percent) {
        percent = Math.max(1, Math.min(100, percent));
        stack.getOrCreateTag().putInt(TAG_TIER, percent);
    }

    /** 切换到下一档（循环）。 */
    public static int cycleNext(int current) {
        int[] tiers = getTiers();
        int idx = 0;
        for (int i = 0; i < tiers.length; i++) {
            if (tiers[i] == current) {
                idx = i;
                break;
            }
        }
        idx = (idx + 1) % tiers.length;
        return tiers[idx];
    }

    // ==================== 速度系数（供属性修饰符事件调用） ====================

    /**
     * 返回该玩家当前应当乘上的速度系数 k（1.0 = 无减速）。
     * 只有装备在护符(charm)或通用(curio)槽位时才会 &lt; 1.0。
     * 若装备了多个，取最慢（数值最小）的那个。
     */
    public static float getSpeedFactor(Player player) {
        try {
            ICuriosItemHandler inv = CuriosApi.getCuriosInventory(player).resolve().orElse(null);
            if (inv == null) {
                return 1.0F;
            }
            int strongest = Integer.MAX_VALUE;
            for (SlotResult result : inv.findCurios(ModItems.KING_TURTLE_CLOCK.get())) {
                int tier = getTier(result.stack());
                if (tier < strongest) {
                    strongest = tier;
                }
            }
            if (strongest == Integer.MAX_VALUE) {
                return 1.0F;
            }
            return strongest / 100.0F;
        } catch (Throwable t) {
            return 1.0F;
        }
    }

    // ==================== 手持右键切换 ====================

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int current = getTier(stack);
            int next = cycleNext(current);
            setTier(stack, next);
            player.displayClientMessage(
                    Component.translatable("item.kingturtle.king_turtle_clock.set",
                            next, 100 - next),
                    false);
        }
        return InteractionResultHolder.success(stack);
    }

    // ==================== Tooltip ====================

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int tier = getTier(stack);
        tooltip.add(Component.translatable("item.kingturtle.king_turtle_clock.value", tier, 100 - tier));
        tooltip.add(Component.translatable("item.kingturtle.king_turtle_clock.desc"));
        tooltip.add(Component.translatable("item.kingturtle.king_turtle_clock.hint"));
    }
}
