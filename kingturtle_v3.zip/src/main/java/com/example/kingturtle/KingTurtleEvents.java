package com.example.kingturtle;

import com.example.kingturtle.item.KingTurtleClockItem;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * 王八钟 v3.0 核心逻辑：把减速做成 {@code MOVEMENT_SPEED} 属性上的
 * {@code MULTIPLY_TOTAL} 修饰符，也就是"独立乘法乘区"。
 *
 * <p>每个服务端 tick 检测一次玩家是否佩戴王八钟，并让属性修饰符与佩戴状态保持一致：</p>
 * <ul>
 *   <li>未佩戴（系数 1.0）：不挂修饰符。</li>
 *   <li>已佩戴（系数 k）：挂一个 amount = k - 1 的 MULTIPLY_TOTAL 修饰符。</li>
 *   <li>档位变化或取下：先移除旧修饰符，再按最新状态决定是否重新挂上。</li>
 * </ul>
 *
 * <p>使用固定 UUID + {@code addTransientModifier}（临时修饰符不写入存档），
 * 因此不会重复叠加，也不会在重登/换维度后残留。</p>
 */
@Mod.EventBusSubscriber(modid = KingTurtleMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class KingTurtleEvents {

    /** 固定 UUID，用于唯一定位本模组的减速修饰符。 */
    private static final UUID SLOW_MODIFIER_ID = UUID.fromString("8f3c1d2e-4a5b-4c6d-9e0f-1a2b3c4d5e6f");
    private static final String SLOW_MODIFIER_NAME = "kingturtle_slow";

    private KingTurtleEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player == null || player.level().isClientSide) {
            return;
        }

        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) {
            return;
        }

        // 目标速度系数 k（1.0 = 不减速）。MULTIPLY_TOTAL 的 amount = k - 1。
        float factor = KingTurtleClockItem.getSpeedFactor(player);
        double desiredAmount = factor - 1.0D;

        AttributeModifier existing = speed.getModifier(SLOW_MODIFIER_ID);

        // 状态已经一致，无需改动。
        if (existing != null && Math.abs(existing.getAmount() - desiredAmount) < 1.0E-6D) {
            return;
        }

        if (existing != null) {
            speed.removeModifier(SLOW_MODIFIER_ID);
        }

        if (Math.abs(desiredAmount) > 1.0E-6D) {
            speed.addTransientModifier(new AttributeModifier(
                    SLOW_MODIFIER_ID,
                    SLOW_MODIFIER_NAME,
                    desiredAmount,
                    AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }
}
