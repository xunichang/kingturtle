package com.example.kingturtle;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * 王八钟 / King Turtle Clock v3.0
 *
 * <p>用属性修饰符 {@code MULTIPLY_TOTAL} 实现减速：直接进入"独立乘法乘区"，
 * 在所有其它移速计算之后整体乘一个系数，同时覆盖行走与疾跑；取下立即恢复。</p>
 *
 * <p>档位 95%..5%，每 5% 一档，共 19 档，手持右键循环切换。
 * 佩戴槽位限定为护符(charm)与通用(curio)。</p>
 */
@Mod(KingTurtleMod.MODID)
public class KingTurtleMod {

    public static final String MODID = "kingturtle";

    public KingTurtleMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.register(modEventBus);
        modEventBus.addListener(this::addCreative);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.KING_TURTLE_CLOCK.get());
        }
    }
}
