package com.example.kingturtle;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public final class Config {

    public static final ForgeConfigSpec SPEC;
    public static final Common COMMON;

    static {
        Pair<Common, ForgeConfigSpec> pair = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = pair.getLeft();
        SPEC = pair.getRight();
    }

    private Config() {
    }

    public static class Common {

        public final ForgeConfigSpec.IntValue defaultTier;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> tiers;

        Common(ForgeConfigSpec.Builder builder) {
            builder.comment("王八钟配置").push("general");

            // 95, 90, ..., 5 (19 档)
            List<Integer> defaultTiers = Arrays.stream(new int[]{
                    95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15, 10, 5
            }).boxed().collect(Collectors.toList());

            tiers = builder
                    .comment("可选减速档位（百分比），默认 95% 到 5% 每 5% 一档")
                    .defineList("tiers", defaultTiers, o -> o instanceof Integer && (Integer) o >= 1 && (Integer) o <= 100);

            defaultTier = builder
                    .comment("新合成饰品的初始减速档位（百分比）")
                    .defineInRange("defaultTier", 95, 1, 100);

            builder.pop();
        }
    }
}
